package hello.security.main.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import hello.security.main.entities.TailorMaster;
@Repository

public interface TailorMasterRepo extends JpaRepository<TailorMaster, Long>{
	TailorMaster findByUsername(String username);

}
