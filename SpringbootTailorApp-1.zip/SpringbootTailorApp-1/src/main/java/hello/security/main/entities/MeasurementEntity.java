package hello.security.main.entities;

import java.time.LocalDate;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "measurements")
public class MeasurementEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // 🔗 Many measurements belong to ONE customer
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private CustomerEntity customer;

    // 👕 Upper Body Measurements
    private Double chest;
    private Double waist;
    private Double hip;
    private Double shoulder;
    private Double sleeveLength;
    private Double neck;

    // 👖 Pant Measurements
    private Double pantLength;
    private Double pantWaist;
    private Double pantBottom;

    // 📝 Comment / Advice
    @Column(columnDefinition = "TEXT")
    private String comment;
 

    // 📅 Measurement Date
    @CreationTimestamp
    @Column(updatable = false)
    private LocalDate measurementDate;

    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public CustomerEntity getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerEntity customer) {
		this.customer = customer;
	}

	public Double getChest() {
		return chest;
	}

	public void setChest(Double chest) {
		this.chest = chest;
	}

	public Double getWaist() {
		return waist;
	}

	public void setWaist(Double waist) {
		this.waist = waist;
	}

	public Double getHip() {
		return hip;
	}

	public void setHip(Double hip) {
		this.hip = hip;
	}

	public Double getShoulder() {
		return shoulder;
	}

	public void setShoulder(Double shoulder) {
		this.shoulder = shoulder;
	}

	public Double getSleeveLength() {
		return sleeveLength;
	}

	public void setSleeveLength(Double sleeveLength) {
		this.sleeveLength = sleeveLength;
	}

	public Double getNeck() {
		return neck;
	}

	public void setNeck(Double neck) {
		this.neck = neck;
	}

	public Double getPantLength() {
		return pantLength;
	}

	public void setPantLength(Double pantLength) {
		this.pantLength = pantLength;
	}

	public Double getPantWaist() {
		return pantWaist;
	}

	public void setPantWaist(Double pantWaist) {
		this.pantWaist = pantWaist;
	}

	public Double getPantBottom() {
		return pantBottom;
	}

	public void setPantBottom(Double pantBottom) {
		this.pantBottom = pantBottom;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public LocalDate getMeasurementDate() {
		return measurementDate;
	}

	public void setMeasurementDate(LocalDate measurementDate) {
		this.measurementDate = measurementDate;
	}

	
    
    
}
