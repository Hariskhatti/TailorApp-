package hello.security.main.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import hello.security.main.entities.MeasurementEntity;
@Repository

public interface MeasurementRepo extends JpaRepository<MeasurementEntity, Long>{
//	MeasurementEntity findByCustomerId(Long customerId);
List<MeasurementEntity> findByCustomerId(Long customerId);


}
