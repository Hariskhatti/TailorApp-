package hello.security.main;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import hello.security.main.entities.CustomerEntity;
import hello.security.main.entities.CustomerMeasurementDTO;
import hello.security.main.entities.MeasurementEntity;
import hello.security.main.entities.TailorMaster;
import hello.security.main.repositories.CustomerRepo;
import hello.security.main.repositories.MeasurementRepo;
import hello.security.main.serviceLayer.ServiceInterface;

@Controller
public class MasterController {
	@Autowired
	private ServiceInterface si;
	@Autowired
	private CustomerRepo cRepo;
	@Autowired
	private MeasurementRepo mRepo;
	
	@GetMapping("/login")
	String loginPage() {
		return "login";
	}
	
	@GetMapping("/dashboard")
	String loginUser(@ModelAttribute TailorMaster tm) {
		return "dashboard";
	}
	@GetMapping("/add-customer")
	String addCustomer(Model model) {
		model.addAttribute("dtoObj", new CustomerMeasurementDTO());
		return "add-customer";
	}
	@PostMapping("/added-customer")
	String addCustomerWithMeasuremnt(@ModelAttribute CustomerMeasurementDTO dto, RedirectAttributes redirectAttributes) {
		si.saveMeasurement(dto);
		 redirectAttributes.addFlashAttribute(
			        "successMessage",
			        "Customer saved successfully!"
			    );
	    return "redirect:/add-customer";
	}
	
	@GetMapping("/customer/list")
	String customerList(Model model) {
		model.addAttribute("customers", cRepo.findAll());
	    return "view-customers";
	}
	
	@GetMapping("/customer/delete/{id}")
	String deleteUser(@PathVariable Long id) {
		si.deleteUser(id);
	    return "redirect:/customer/list";
	}
	
	@GetMapping("/customer/edit/{id}")
	String editCustomer(@PathVariable Long id, Model model) {
		model.addAttribute("customerObj", cRepo.findById(id));
		return "edit-customer";
	}
	
	@PostMapping("/customer/update")
	String updateCustomer(@ModelAttribute CustomerEntity ce) {
		si.editCustomer(ce);
	    return "redirect:/customer/list";
	}
	
	
	// add another measurement
    @GetMapping("/measurement/add/{customerId}")
    public String addMeasurementPage(@PathVariable Long customerId, Model model) {

        CustomerEntity customer = cRepo.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        MeasurementEntity measurement = new MeasurementEntity();

        model.addAttribute("customer", customer);
        model.addAttribute("measurement", measurement);

        return "add-measurement";
    }

    // add another measurement save method
    @PostMapping("/measurement/save")
    public String saveMeasurement(@RequestParam Long customerId,
                                  @ModelAttribute MeasurementEntity measurement,
                                  RedirectAttributes redirectAttributes) {

        // ✅ Check if all measurement fields are null or empty
        boolean allEmpty = (measurement.getChest() == null &&
                            measurement.getWaist() == null &&
                            measurement.getHip() == null &&
                            measurement.getShoulder() == null &&
                            measurement.getSleeveLength() == null &&
                            measurement.getNeck() == null &&
                            measurement.getPantLength() == null &&
                            measurement.getPantWaist() == null &&
                            measurement.getPantBottom() == null &&
                            (measurement.getComment() == null || measurement.getComment().trim().isEmpty()));

        if (allEmpty) {
            redirectAttributes.addFlashAttribute("error", "Cannot save empty measurement!");
            return "redirect:/measurement/add/" + customerId;
        }

        CustomerEntity customer = cRepo.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        measurement.setCustomer(customer);   // ⭐ IMPORTANT
        mRepo.save(measurement);
        redirectAttributes.addFlashAttribute("success", "Measurement saved successfully!");

        return "redirect:/measurement/edit/" + customerId;
    }

    
    // customer list for measurement
    @GetMapping("/measurements")
    public String measurementCustomerList(Model model) {

        model.addAttribute("customers", cRepo.findAll());

        return "customer-measurement-manager";
    }
    
    // measurement view
    @GetMapping("/measurement/view/{customerId}")
    public String viewMeasurementsByCustomer(
            @PathVariable Long customerId,
            Model model) {

        CustomerEntity customer = cRepo.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        List<MeasurementEntity> measurements =
                mRepo.findByCustomerId(customerId);

        model.addAttribute("customer", customer);
        model.addAttribute("measurements", measurements);

        return "view-measurements";
    }


    // measurement update
    @PostMapping("/measurement/update")
    public String updateMeasurement(
            @RequestParam Long customerId,
            @ModelAttribute MeasurementEntity measurement,
            RedirectAttributes redirectAttributes) {

        CustomerEntity customer = cRepo.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        measurement.setCustomer(customer);
        mRepo.save(measurement);

        redirectAttributes.addFlashAttribute("success", "Measurement updated successfully");

        return "redirect:/measurement/view/" + customerId;
    }
    
    // measurement delete 
    @GetMapping("/measurement/delete/{id}")
    public String deleteMeasurement(@PathVariable Long id,
                                    RedirectAttributes redirectAttributes) {

        MeasurementEntity measurement = mRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Measurement not found"));

        Long customerId = measurement.getCustomer().getId();

        mRepo.deleteById(id);

        redirectAttributes.addFlashAttribute("success", "Measurement deleted successfully");

        return "redirect:/measurement/view/" + customerId;
    }




}
