package hello.security.main;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import hello.security.main.entities.CustomerEntity;
import hello.security.main.entities.CustomerMeasurementDTO;
import hello.security.main.entities.MeasurementEntity;
import hello.security.main.entities.TailorMaster;
import hello.security.main.repositories.CustomerRepo;
import hello.security.main.repositories.MeasurementRepo;
import hello.security.main.repositories.TailorMasterRepo;
import hello.security.main.serviceLayer.ServiceInterface;

@Service
public class ServiceClass implements UserDetailsService, ServiceInterface{
	@Autowired
	private TailorMasterRepo tmRepo;
	@Autowired
	private CustomerRepo cRepo;
	@Autowired
	private MeasurementRepo mRepo;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		TailorMaster tm = tmRepo.findByUsername(username);
		 if (tm == null) {
		        throw new UsernameNotFoundException("User not found");
		    }
		 return org.springframework.security.core.userdetails.User
				    .withUsername(tm.getUsername())
				    .password(tm.getPassword())
				    .accountExpired(false)
				    .accountLocked(false)
				    .credentialsExpired(false)
				    .disabled(false)   // VERY IMPORTANT
				    .build(); 

	}

	@Override
	public MeasurementEntity saveMeasurement(CustomerMeasurementDTO dto) {
		
		CustomerEntity ce = new CustomerEntity();
		ce.setName(dto.getName());
		ce.setGender(dto.getGender());
		ce.setPhoneNumber(dto.getPhoneNumber());
		ce.setAddress(dto.getAddress());
		
		CustomerEntity savedCustomer = cRepo.save(ce);
		//MeasurementEntity Fields
		MeasurementEntity me = new MeasurementEntity();

		// 👔 Shirt / Kurta Measurements
		me.setChest(dto.getChest());
		me.setWaist(dto.getWaist());
		me.setHip(dto.getHip());
		me.setShoulder(dto.getShoulder());
		me.setSleeveLength(dto.getSleeveLength());
		me.setNeck(dto.getNeck());

		// 👖 Pant Measurements
		me.setPantLength(dto.getPantLength());
		me.setPantWaist(dto.getPantWaist());
		me.setPantBottom(dto.getPantBottom());

		// 📝 Comment & Meta
		me.setComment(dto.getComment());
		me.setMeasurementDate(LocalDate.now());
		me.setCustomer(savedCustomer);
		return mRepo.save(me);
	}

	@Override
	public void deleteUser(Long id) {
		// TODO Auto-generated method stub
		cRepo.deleteById(id);
	}

	@Override
	public CustomerEntity editCustomer(CustomerEntity ce) {
		CustomerEntity cee = new CustomerEntity();
		cee.setId(ce.getId());
		cee.setName(ce.getName());
		cee.setGender(ce.getGender());
		cee.setPhoneNumber(ce.getPhoneNumber());
		cee.setAddress(ce.getAddress());
		
		return cRepo.save(cee);
	}

	@Override
	public MeasurementEntity updateMeasurement(Long id, CustomerMeasurementDTO dto) {
		MeasurementEntity mee = mRepo.findById(id).orElseThrow();
		mee.setChest(dto.getChest());
		mee.setWaist(dto.getWaist());
		mee.setHip(dto.getHip());
		mee.setShoulder(dto.getShoulder());
		mee.setSleeveLength(dto.getSleeveLength());
		mee.setNeck(dto.getNeck());

		// 👖 Pant Measurements
		mee.setPantLength(dto.getPantLength());
		mee.setPantWaist(dto.getPantWaist());
		mee.setPantBottom(dto.getPantBottom());

		// 📝 Comment & Meta
		mee.setComment(dto.getComment());
		mee.setMeasurementDate(LocalDate.now());
		return mRepo.save(mee);
	}

	@Override
	public MeasurementEntity saveAnotherMeasurement(CustomerMeasurementDTO dto) {
		MeasurementEntity m = new MeasurementEntity();
		
		m.setChest(dto.getChest());
		m.setWaist(dto.getWaist());
		m.setHip(dto.getHip());
		m.setShoulder(dto.getShoulder());
		m.setSleeveLength(dto.getSleeveLength());
		m.setNeck(dto.getNeck());

		// 👖 Pant Measurements
		m.setPantLength(dto.getPantLength());
		m.setPantWaist(dto.getPantWaist());
		m.setPantBottom(dto.getPantBottom());

		// 📝 Comment & Meta
		m.setComment(dto.getComment());
		return mRepo.save(m);
	}


}
