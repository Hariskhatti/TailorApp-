package hello.security.main.entities;

public class CustomerMeasurementDTO {

    // 👤 Customer fields
    private String name;
    private String phoneNumber;
    private String address;
    private String gender;

    // 👔 Shirt / Kurta Measurements
    private Double chest;
    private Double waist;
    private Double hip;
    private Double shoulder;
    private Double sleeveLength;
    private Double neck;

    // 👖 Pant Measurements
    private Double pantLength;
    private Double pantWaist;
    private Double pantBottom;

    // 📝 Comment / Advice
    private String comment;

    // ---------------- GETTERS & SETTERS ----------------

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Double getChest() {
        return chest;
    }

    public void setChest(Double chest) {
        this.chest = chest;
    }

    public Double getWaist() {
        return waist;
    }

    public void setWaist(Double waist) {
        this.waist = waist;
    }

    public Double getHip() {
        return hip;
    }

    public void setHip(Double hip) {
        this.hip = hip;
    }

    public Double getShoulder() {
        return shoulder;
    }

    public void setShoulder(Double shoulder) {
        this.shoulder = shoulder;
    }

    public Double getSleeveLength() {
        return sleeveLength;
    }

    public void setSleeveLength(Double sleeveLength) {
        this.sleeveLength = sleeveLength;
    }

    public Double getNeck() {
        return neck;
    }

    public void setNeck(Double neck) {
        this.neck = neck;
    }

    public Double getPantLength() {
        return pantLength;
    }

    public void setPantLength(Double pantLength) {
        this.pantLength = pantLength;
    }

    public Double getPantWaist() {
        return pantWaist;
    }

    public void setPantWaist(Double pantWaist) {
        this.pantWaist = pantWaist;
    }

    public Double getPantBottom() {
        return pantBottom;
    }

    public void setPantBottom(Double pantBottom) {
        this.pantBottom = pantBottom;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
