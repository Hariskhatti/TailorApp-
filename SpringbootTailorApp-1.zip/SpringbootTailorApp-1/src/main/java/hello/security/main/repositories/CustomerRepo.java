package hello.security.main.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import hello.security.main.entities.CustomerEntity;
@Repository
public interface CustomerRepo extends JpaRepository<CustomerEntity, Long>{

	

}
