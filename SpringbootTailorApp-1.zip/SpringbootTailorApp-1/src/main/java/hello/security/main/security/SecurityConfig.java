package hello.security.main.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@EnableWebSecurity
@Configuration
public class SecurityConfig {
	@Bean
	SecurityFilterChain filterChain(HttpSecurity http) {
		http.csrf(Customizer->Customizer.disable());
		http.authorizeHttpRequests(auth-> auth.requestMatchers("/login").permitAll().anyRequest().authenticated());
		http.formLogin(form -> form
                .loginPage("/login")
                .loginProcessingUrl("/loginUser") // IMPORTANT
                .defaultSuccessUrl("/dashboard", true)
                .failureUrl("/login?error=true")
                .permitAll()
            )
            .logout(logout -> logout
                .logoutSuccessUrl("/login?logout=true")
            );

		return http.build();
			
	}
	
	@Bean
	PasswordEncoder encode() {
		return new BCryptPasswordEncoder();
	}



}
