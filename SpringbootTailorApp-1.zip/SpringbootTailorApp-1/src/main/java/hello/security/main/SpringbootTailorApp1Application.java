package hello.security.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootTailorApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootTailorApp1Application.class, args);
	}

}
