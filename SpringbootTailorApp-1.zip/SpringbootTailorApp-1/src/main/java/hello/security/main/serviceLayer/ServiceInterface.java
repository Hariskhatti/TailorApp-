package hello.security.main.serviceLayer;

import hello.security.main.entities.CustomerEntity;
import hello.security.main.entities.CustomerMeasurementDTO;
import hello.security.main.entities.MeasurementEntity;

public interface ServiceInterface {
MeasurementEntity saveMeasurement(CustomerMeasurementDTO dto);
void deleteUser(Long id);
CustomerEntity editCustomer (CustomerEntity ce);
MeasurementEntity updateMeasurement(Long id,CustomerMeasurementDTO dto);
MeasurementEntity saveAnotherMeasurement(CustomerMeasurementDTO dto);


}
